#!/bin/bash

cmake -DTENGINE_DIR=/home/usr/tengine \
      ..
