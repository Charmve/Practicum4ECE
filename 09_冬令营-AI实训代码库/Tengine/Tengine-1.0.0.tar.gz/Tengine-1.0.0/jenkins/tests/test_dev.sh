
function run_test()
{
    cd ${ROOT_DIR}
	./build/internal/bin/test_dev
    return 0
}

SUCCESS_STRING="0.2763 - \"n02123045"
