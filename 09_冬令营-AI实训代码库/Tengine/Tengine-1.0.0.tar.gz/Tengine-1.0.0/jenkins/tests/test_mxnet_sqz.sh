
function run_test()
{
    cd ${ROOT_DIR}
    ./build/tests/bin/test_mxnet_sqz
    return 0
}

SUCCESS_STRING="0.2344 - \"n02123045"
