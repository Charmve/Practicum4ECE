
function run_test()
{
    cd ${ROOT_DIR}
    ./build/tests/bin/test_onnx_sqz
    return 0
}

SUCCESS_STRING="0.7178 - \"n02123045"
