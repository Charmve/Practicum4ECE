
function run_test()
{
    cd ${ROOT_DIR}
    ./tests/bin/vgg16_mem.sh
    return 0
}

SUCCESS_STRING="0.4998 - \"n03792782"
