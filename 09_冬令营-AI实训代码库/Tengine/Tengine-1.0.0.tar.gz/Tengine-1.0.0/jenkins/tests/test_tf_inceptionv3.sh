
function run_test()
{
    cd ${ROOT_DIR}
    ./build/tests/bin/test_tf_inceptionv3
    return 0
}

SUCCESS_STRING="0.7361 - \"military uniform"
