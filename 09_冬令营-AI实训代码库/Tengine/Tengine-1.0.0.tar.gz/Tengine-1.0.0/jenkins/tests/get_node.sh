
function run_test()
{
    cd ${ROOT_DIR}
	./build/internal/bin/test_get_node
    return 0
}

SUCCESS_STRING="0.2763 - \"n02123045"
