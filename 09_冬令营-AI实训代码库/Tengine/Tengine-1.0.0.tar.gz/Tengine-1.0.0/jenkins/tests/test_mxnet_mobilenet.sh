
function run_test()
{
    cd ${ROOT_DIR}
    ./build/tests/bin/test_mxnet_mobilenet
    return 0
}

SUCCESS_STRING="8.0579 - \"n02124075"
